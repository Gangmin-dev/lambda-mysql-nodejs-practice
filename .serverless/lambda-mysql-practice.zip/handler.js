"use strict";
const db = require("./module/db");
const template = require("./module/template");
const api = require("lambda-api")();

api.get("/class/:id", async (req, res) => {
  db.query(`SELECT * FROM class WHERE id = ?`, [req.params.id], (err, cla) => {
    if (err) throw err;
    db.query(
      `SELECT * FROM student WHERE class_id =?`,
      [req.params.id],
      (err2, students) => {
        if (err2) throw err2;
        let title = cla[0].name + " - " + cla[0].teacher;
        let list = template.list(students);
        let html = template.html(title, list, "");
        res.status(200);
        res.type(".html");
        res.html(html);
      }
    );
  });
});

module.exports.main = async (event, context) => {
  return await api.run(event, context);

  // db.query(`SELECT * FROM student`, (err, students, fields) => {
  //   if (err) throw err;
  //   console.log(
  //     `${students[0].id}의 id를 가진 ${students[0].name}은 ${students[0].class_id}반에 있다.`
  //   );
  // });
};
