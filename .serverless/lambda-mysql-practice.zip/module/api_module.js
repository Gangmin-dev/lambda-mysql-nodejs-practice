"use strict";

const api = require("lambda-api")();

api.get("/class/:id", async (req, res) => {});
